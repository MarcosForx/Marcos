import UIKit
/*
struct Persona {
    var name:String
    func sayHello(){
        print("Holaaaa, soy  \(name)")
    }
}

let persona: Persona = Persona(name: "El indestructible Mushuuu")

persona.sayHello()
*/

//INICIALIZADOR ADAPTADO

struct Temperatura{ //inicializador
    var celsius: Double

    //inicializador bàsica que crea swit
    init(celsius:Double) {
        self.celsius = celsius

    }
    // esta es la que creamos nosotros y tambien hay que agregar la basica
    init(fahrenheit:Double) {
        celsius = (fahrenheit-32)/1.8

    }
    
}
let instancia1 = Temperatura()







